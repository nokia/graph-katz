//KIG with vertex importance option

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "aux_functions.h"
#include "similarity_measures.h"

void main(int argc, char **argv){
	
	char * file_name1 = argv[1];
	char * file_name2 = argv[2];
	double alpha = atof(argv[3]);
	double gamma = atof(argv[4]);
	int num_vertices = atoi(argv[5]);
	char * output_file_name = argv[6];
  
  
  //---------------- Read in Taxonomy 1
  int*** Tx1 = readEdgeListFile(file_name1, num_vertices);
  //printf("Read edges for Tx1\n");
  int * Ord1 = getTopologicalOrdering(Tx1, num_vertices);
  //printf("Computed top order for Tx1\n");
  double* KIV1mat = computeKIV( Tx1,  Ord1,  num_vertices, alpha);
  //printf("Computed KIV for Tx1\n");
  
  //---------------- Read in Taxonomy 2
  int*** Tx2 = readEdgeListFile(file_name2, num_vertices);
  //printf("Read edges for Tx2\n");
  int * Ord2 = getTopologicalOrdering(Tx2, num_vertices);
  //printf("Computed top order for Tx2\n");
  double* KIV2mat = computeKIV( Tx2,  Ord2,  num_vertices, alpha);
  //printf("Computed KIV for Tx2\n");
  
  double * resArray = (double*)malloc(5*sizeof(double));
  
  double * vertexImportance = (double*)malloc(num_vertices*sizeof(double));
  
  double KIGc = computeKIG( KIV1mat, KIV2mat, num_vertices, resArray, vertexImportance);
  
  printf("KIG-c value is %lf\n", KIGc);
  
  FILE * fp;
  fp = fopen(output_file_name,"w");
  fprintf(fp,"%30.4lf \t %30.4lf \t %30.4lf \t %30.4lf \t %30.4lf", KIGc, resArray[1], resArray[2], resArray[3], resArray[4]);
  fclose(fp);
  
  if(argc >7){
	  char * output_file_name_importance = argv[7];
	  fp = fopen(output_file_name_importance,"w");
	  int i =0;
	  for(i=0; i<num_vertices;i++) fprintf(fp, "%30.4lf\n", vertexImportance[i]);
	  fclose(fp);
  }
  
  freeTx(Tx1,num_vertices);
  freeTx(Tx2,num_vertices);
  
  
  free(resArray);
  free(vertexImportance);
  free(Ord1);
  free(Ord2);
  free(KIV1mat);
  free(KIV2mat);
  return;
}
