//KSG with vertex importance option

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "aux_functions.h"
#include "similarity_measures.h"

void main(int argc, char **argv){
	
	char * file_name1 = argv[1];
	char * file_name2 = argv[2];
	double alpha = atof(argv[3]);
	double gamma = atof(argv[4]);
	int num_vertices = atoi(argv[5]);
	char * output_file_name = argv[6];
	
  
  //---------------- Read in Taxonomy 1
  //const char * file_name1 = "../../Data/DBpedia_edges.txt";
  //const char * file_name1 = "../../Data/Death_edges_test.txt";
  int*** Tx1 = readEdgeListFile(file_name1, num_vertices);
  //printf("Read edges for Tx1\n");
  //return;
  int * Ord1 = getTopologicalOrdering(Tx1, num_vertices);
  //printf("Computed top order for Tx1\n");
  KSV* K1 = computeKSV( Tx1,  Ord1,  num_vertices, alpha);
  //printf("Computed KSV for Tx1\n");
  //return;
  
  //---------------- Read in Taxonomy 2
  //const char * file_name2 = "../../Data/DBpedia_edges.txt";
  //const char * file_name2 = "../../Data/tx2_edges_test.txt";
  int*** Tx2 = readEdgeListFile(file_name2, num_vertices);
  //printf("Read edges for Tx2\n");
  int * Ord2 = getTopologicalOrdering(Tx2, num_vertices);
  //printf("Computed top order for Tx2\n");
  KSV* K2 = computeKSV( Tx2,  Ord2,  num_vertices, alpha);
  //printf("Computed KSV for Tx2\n");
  
  double * vertexImportance = (double*)malloc(num_vertices*sizeof(double));
  
  double KSG1c = computeKSG( K1->KSVmat, K1->KSVnz, K2->KSVmat, K2->KSVnz,num_vertices, vertexImportance);
  
  printf("KSG-c value is %lf\n", KSG1c);
  
  FILE * fp;
  fp = fopen(output_file_name,"w");
  fprintf(fp,"%lf", KSG1c);
  fclose(fp);
  
  if(argc >7){
	  char * output_file_name_importance = argv[7];
	  fp = fopen(output_file_name_importance,"w");
	  int i =0;
	  for(i=0; i<num_vertices;i++) fprintf(fp, "%30.4lf\n", vertexImportance[i]);
	  fclose(fp);
  }
  
  freeTx(Tx1,num_vertices);
  freeTx(Tx2,num_vertices);
  
  int i;
  for(i=1;i<=num_vertices;i++) free(K1->KSVmat[i-1]);
  free(K1->KSVmat);
  for(i=1;i<=num_vertices;i++) free(K1->KSVnz[i-1]);
  free(K1->KSVnz);
  free(K1);
  
  for(i=1;i<=num_vertices;i++) free(K2->KSVmat[i-1]);
  free(K2->KSVmat);
  for(i=1;i<=num_vertices;i++) free(K2->KSVnz[i-1]);
  free(K2->KSVnz);
  free(K2);
  
  free(vertexImportance);
  free(Ord1);
  free(Ord2);
  return;
}
