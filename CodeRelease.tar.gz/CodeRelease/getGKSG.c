// GKSG with vertex importance option


#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "aux_functions.h"
#include "similarity_measures.h"

void main(int argc, char **argv){
	
	char * file_name1 = argv[1];
	char * file_name2 = argv[2];
	double alpha = atof(argv[3]);
	double gamma = atof(argv[4]);
	int num_vertices = atoi(argv[5]);
	int num_groups = atoi(argv[6]);
	char * output_file_name = argv[7];
	
  
  srand(time(NULL));   // should only be called once
  
  int * GroupIdx = (int*)malloc(num_vertices*sizeof(int));
  int i, r;
  for(i=1;i<=num_vertices;i++) GroupIdx[i-1] = rand()%num_groups + 1; ; // randomly assign a positive integer from 1 to num_groups
  
  //---------------- Read in Taxonomy 1
  int*** Tx1 = readEdgeListFile(file_name1, num_vertices);
  //printf("Read edges for Tx1\n");
  int * Ord1 = getTopologicalOrdering(Tx1, num_vertices);
  //printf("Computed top order for Tx1\n");
  GKSV* GKS1 = computeGKSV( Tx1,  Ord1,  num_vertices, alpha, GroupIdx, num_groups);
  //printf("Computed GKSV for Tx1\n");
  
  //---------------- Read in Taxonomy 2
  int*** Tx2 = readEdgeListFile(file_name2, num_vertices);
  //printf("Read edges for Tx2\n");
  int * Ord2 = getTopologicalOrdering(Tx2, num_vertices);
  //printf("Computed top order for Tx2\n");
  GKSV* GKS2 = computeGKSV( Tx2,  Ord2,  num_vertices, alpha, GroupIdx, num_groups);
  //printf("Computed GKSV for Tx2\n");
  
  double * vertexImportance = (double*)malloc(num_vertices*sizeof(double));
  double GKSGc = computeGKSG( GKS1, GKS2, vertexImportance);
  
  printf("GKSG-c value is %lf\n", GKSGc);
  if(argc >7){
	  char * output_file_name_importance = argv[7];
	  fp = fopen(output_file_name_importance,"w");
	  int i =0;
	  for(i=0; i<num_vertices;i++) fprintf(fp, "%30.4lf\n", vertexImportance[i]);
	  fclose(fp);
  }
  
  FILE * fp;
  fp = fopen(output_file_name,"w");
  fprintf(fp,"%lf", GKSGc);
  fclose(fp);
  
  freeTx(Tx1,num_vertices);
  freeTx(Tx2,num_vertices);
  
  for(i=1;i<=num_groups;i++) free(GKS1->GKSVmat[i-1]);
  free(GKS1->GKSVmat);
  free(GKS1);
  for(i=1;i<=num_groups;i++) free(GKS2->GKSVmat[i-1]);
  free(GKS2->GKSVmat);
  free(GKS2);
  
  free(Ord1);
  free(Ord2);
  free(GroupIdx);
  return;
}
